# Prism — merged build (Livio + Screen Shield)

This project combines the two A07 variants into one app:

* **Base:** the “livio” build — encrypted Room database, local rule + ML scanner, manual scan,
  history, whitelist / blacklist, subscription UI, and the (still unwired) Node backend.
* **Added:** the accessibility **Screen Shield** — automatic URL capture from chats and browsers,
  plus the full-screen danger / caution overlay.

The important part is that both halves now share **one detection pipeline**:

```
screen text ──► UrlExtractor ──► ScreenScanCoordinator ──► ScanRepository
                                                          ├─ 1 blacklist
                                                          ├─ 2 whitelist
                                                          ├─ 3 encrypted URL cache
                                                          ├─ 4 ManualScanAnalyzer (rules + ML)
                                                          └─ 5 save to Room history
                                                                 │
                    ThreatShieldController ◄── UrlVerdict ◄──────┘
                    (danger / caution overlay)        Dashboard, History, counters
```

Because the screen path writes through `ScanRepository`, a link caught on screen:

* appears in **History** and moves **Scans / Blocked / Alerts**,
* respects the same **trusted / blocked** hosts as Manual Scan,
* benefits from the 7-day URL cache,
* and shows the same reasons the manual scanner produces.

The shield additionally runs its own `UrlHeuristics` in parallel and takes the **more dangerous**
of the two verdicts. That closes brand gaps in the manual scanner (Discord, Steam, Taiwanese banks,
…) without downgrading anything the rule+ML scanner already caught.

If the encrypted database or `url_model.json` cannot be opened, the shield falls back to
`UrlHeuristics` instead of failing open.

## What was added

| File | Purpose |
| --- | --- |
| `accessibility/PhishingDetectionService.kt` | Accessibility service: events, throttling, click guard, shield, trust action. |
| `accessibility/ScreenScanCoordinator.kt` | Bridge to `ScanRepository` / `ManualScanAnalyzer`; maps `ManualScanOutcome` → `UrlVerdict`; heuristics fallback. |
| `accessibility/UrlExtractor.kt` | Bounded tree walk; browsers are scanned address-bar only. |
| `accessibility/UrlTextParser.kt` | URL discovery and normalisation (scheme-less links, `hxxp`, `[.]`, CJK adjacency). |
| `accessibility/UrlHeuristics.kt` | Offline fallback scoring (brand spoofing, `@` tricks, punycode, risky TLDs, …). |
| `accessibility/ThreatShieldOverlay.kt` + `res/layout/prism_threat_shield.xml` | Full-screen `TYPE_ACCESSIBILITY_OVERLAY` shield. |
| `accessibility/ScreenShieldSettings.kt` | Overlay / “monitor all apps” switches. |
| `accessibility/MonitoredApps.kt` | WhatsApp, LINE, Telegram, Gmail, Chrome, … package list. |
| `accessibility/AccessibilityServiceState.kt` | “Is the shield enabled?” + system-settings intent. |
| `ScreenMonitoringCard.kt` | Dashboard card (Scan tab) that enables/monitors the service. |
| `res/xml/accessibility_service_config.xml` | Event types, window-content access, notification timeout. |

The Android manifest registers the service with `BIND_ACCESSIBILITY_SERVICE`.

## Build & run

1. Open this folder in Android Studio (it is the Gradle root, `settings.gradle.kts` includes `:app`).
2. Let Gradle sync. The project targets **compileSdk 36.1**; Android Studio will offer to install
   the platform and Build Tools if missing. JDK 21 is required (Android Studio bundles it).
3. Run the app on a device/emulator.
4. Log in → **Scan** tab → **AI Screen Monitoring → ENABLE**, accept the accessibility dialog.
5. Open Chrome (or WhatsApp/LINE) and type `paypal-secure-login.tk/verify`:

   * red **PHISHING SHIELD**, risk score from the local rule + ML scanner;
   * “I trust this site” writes the host to the encrypted whitelist;
   * after dismissing, the entry is visible in **History** and the counters have moved.

## Design decisions

* **Livio’s scanner is the single source of truth.** The screen shield does not keep a second
  database; duplicate detection would drift from Manual Scan.
* **Warnings are quieter in chats.** A dangerous link blocks immediately; a suspicious link in a
  chat only shows a toast until it is tapped (a browser page warns immediately).
* **Browsers scan the address bar, not the page.** Otherwise links that merely appear in a news
  article would trigger warnings. Tapping a link is still checked by the click path.
* **Trust is shared.** “I trust this site” in the shield and in the Manual Scan popup modify the
  same Room `whitelist` table, so the UI updates through its existing Flow.
* **Backend unchanged.** `prism-backend/` is copied for context but the app still runs fully
  offline; wiring it is a separate step (INTERNET permission, Retrofit, token storage, base URL
  `http://10.0.2.2:3000`).

## Tests

65 JVM tests pass, including the 28 tests for the shield’s parser/heuristics and Livio’s repository,
scanner, manual-scan and site-action suites:

```bash
./gradlew :app:testDebugUnitTest
```

## Known limitations

* Every unique URL seen on screen is inserted into history, but a URL already handled from the
  screen is skipped for **5 minutes** (interactive clicks bypass this). A busy group chat can still
  fill the history faster than manual scanning would.
* Plan enforcement is still local: the “advanced” scanner rules read the `prism_plan` preference,
  not the backend.
* The accessibility service must be declared in the Play Console; it does not read keystrokes and
  `canPerformGestures` is disabled.
* `.tk` / `.ml` / `.ga` / `.cf` / `.gq` and other abuse-heavy TLDs are parsed as links even without
  a scheme, because browsers hide `https://`.
